
import { NgModule } from '@angular/core';
import { Routes,RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import {ProdDetailComponent} from './prod-detail/prod-detail.component';



const routes: Routes = [
{ path : '', component: LoginComponent },
{ path : '\login', component: LoginComponent },
{ path : '\product_display', component:ProductDisplayComponent},
{ path : '\prod_detail/:product_code', component:ProdDetailComponent},
{ path : '**', component: LoginComponent }
];

@NgModule({
imports:[ RouterModule.forRoot(routes) ],
exports:[ RouterModule ],
providers:[]
})
export class MyRoutingModule { } 
 
