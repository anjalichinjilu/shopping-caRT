import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ProductDisplayComponent } from './product-display/product-display.component';
import { MyRoutingModule} from './app-routing.module';
import {ProductService} from './product-display/product.service';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ProductDisplayComponent,
  
    
  ],
  imports: [
    BrowserModule,
    RouterModule,
    MyRoutingModule,
    HttpModule 
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
