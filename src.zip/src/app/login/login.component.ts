import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core'; 
import {RouterModule} from '@angular/router'
import {AccordionModule} from 'primeng/primeng';     //accordion and accordion tab
import {MenuItem} from 'primeng/primeng';  //api   
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
    clicked(username,password){
   if(username=="anjali" && password=="anj123"){
     alert("Login Successful");
     this.router.navigate(['/product_display']);
     return false;
   }
   else{
     alert("Enter a valid Username and Password");
   }
  }

}
