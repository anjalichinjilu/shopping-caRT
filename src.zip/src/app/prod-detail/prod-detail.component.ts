import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';

import { Subscription }       from 'rxjs/Subscription';

import { Item } from '../product-display/item';
import { ProductService } from '../product-display/product.service';
@Component({
  selector: 'app-prod-detail',
  templateUrl: './prod-detail.component.html',
  styleUrls: ['./prod-detail.component.css']
})
export class ProdDetailComponent implements OnInit {
    pageTitle: string = 'Product Detail';
    product: Item;
    errorMessage: string;
    private sub: Subscription;
    id : any;

    constructor(private route: ActivatedRoute,
                private router: Router,
                private productService: ProductService) {
    }

    ngOnInit(): void {
        this.sub = this.route.params.subscribe(
            params => {
                let id = +params['product_code'];
                this.getProduct(id);
        });
    //           this.productList.map((d)=> {
    //     d.image='./assets/images/'+d.image;
    //   });
    }

    ngOnDestroy() {
        this.sub.unsubscribe();
    }
      

    getProduct(id: number) {
        
        this.productService.getProduct(id).subscribe(
            product => this.product = product,
            
            error => this.errorMessage = <any>error);
            
    }
    logout(){
   this.router.navigate(['/login']);
 }
  gotohome(){
     
    this.router.navigate(['/product_display']);
    
  }

    
}