export class Item{
    product_code: string;
      product_category:string;
      price:number;
      description:string;
      image:string;
}