export class Item{
    product_code: number;
      product_category:string;
      price:number;
      description:string;
      image:string;
}