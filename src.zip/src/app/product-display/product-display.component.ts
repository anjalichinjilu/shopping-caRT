import { Component, OnInit } from '@angular/core';
import { Router,RouterModule } from '@angular/router';

import { Item } from './item';
import { ProductService } from './product.service';


@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent implements OnInit {
      errorMessage: string;

    itemsList: Item[];

  constructor(private router: Router,private productService: ProductService) { }

  ngOnInit() {
    this.productService.getItems()
                .subscribe(items=> {this.itemsList = items;
                  this.itemsList.map((d) =>{
                    
                      d.image='./assets/images/'+ d.image;
                  });
                },error => this.errorMessage = <any>error);
  }

}
