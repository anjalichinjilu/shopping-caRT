import { Injectable } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';

import { Item } from './item';

@Injectable()
export class ProductService {
  // Define the routes we are going to interact with
  private itemsUrl = 'http://localhost:3001/api/items';
  
  constructor(private http: Http) { }

  // Implement a method to get the public deals

    getItems(): Observable<Item[]> {
        return this.http.get(this.itemsUrl)
            .map((response: Response) => <Item[]> response.json())
            .do(data => console.log('All: ' +  JSON.stringify(data)))
            .catch(this.handleError);
    }
  // Implement a method to get the private deals


  // Implement a method to handle errors if any
    private handleError(error: Response) {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}